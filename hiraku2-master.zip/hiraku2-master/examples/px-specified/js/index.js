new Hiraku(".js-offcanvas", {
  btn: ".js-offcanvas-btn",
  fixedHeader: ".js-fixed-header",
  direction: "left",
	breakpoint: 767,
	width: '210px'
});
