new Hiraku(".js-offcanvas-left", {
  btn: ".js-offcanvas-btn-left",
  fixedHeader: ".js-fixed-header",
  direction: "left",
  breakpoint: 767
});

new Hiraku(".js-offcanvas-right", {
  btn: ".js-offcanvas-btn-right",
  fixedHeader: ".js-fixed-header",
  direction: "right",
  breakpoint: 767
});
